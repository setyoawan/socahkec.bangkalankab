

<!DOCTYPE html>
<html>
<head>
	<title><?= $title; ?></title>
	
</head>
<body>


<div class="container bg-light pb-4">
	<div class="row">
		<div class="col">
		<h4>Form untuk memposting artikel</h4>
		</div>
	</div>
	<div class="row">
	
	<div class="col">
	<form method="post" action="<?= base_url('crud/tambah_aksi'); ?>">
		<label for="judul_artikel">Judul Artikel</label>
		<input class="form-control" type="text" name="judul_artikel" required="required" id="judul_artikel"><br>
		
		<label for="isi_artikel">Isi Artikel</label> 
		<textarea class="form-control" name="isi_artikel" required="required" id="isi_artikel" style="height: 315px;"></textarea><br>
		
		<button class="btn btn-primary  float-right" name="submit" type="submit">Buat</button>

	</form>
	</div>
	
	</div>
</div>




</body>

<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('isi_artikel');
</script>
</html>



