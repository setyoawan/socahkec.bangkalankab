
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Author Meta -->
        <meta name="author" content="Themefisher">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">

        <!-- Site Title -->
        <title><?= $title; ?></title>


        <!-- Favicon -->
        <link href="<?= base_url('assets'); ?>/img/bangkalan.png" rel="icon">
        <link href="<?= base_url('assets'); ?>/img/bangkalan.png" rel="apple-touch-icon">

        <!--
        <link href='https://fonts.googleapis.com/css?family=Raleway:200,300,400,700,900,800' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Roboto:200,300,400,900,700,500,300' rel='stylesheet' type='text/css'>
        -->
        
        <!--
        CSS
        ============================================= -->
        <link href="<?= base_url('assets'); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/font-awesome.min.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/owl.carousel.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/justifiedGallery.min.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/et-font.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/animate.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/owl.carousel.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/owl.theme.css">
        <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/main.css">
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->        
    
</head>

<body>
    <!-- #preloader -->
    <!-- end #preloader -->
    <!-- #preloader -->
    <div id="preloader">
        <div class="preloader loading">
            <span class="slice"></span>
            <span class="slice"></span>
            <span class="slice"></span>
            <span class="slice"></span>
            <span class="slice"></span>
            <span class="slice"></span>
        </div>
    </div>
    <!-- end #preloader -->
    <header class="site-header navbar-fixed-top navbar-default">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?= base_url('user'); ?>">
                    <img src="<?= base_url('assets/img/lg2.png'); ?>" alt="">
                </a>
            </div>
            
            <div class="nav-toggle hidden-xs">
                <button class="toggle-btn">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <nav class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav main-manu">
                    <li><a href="<?= base_url('user'); ?>" class="scroll">Beranda</a></li>
                    <li><a href="<?= base_url('user'); ?>#about" class="scroll">Sejarah</a></li>
                    <li><a href="<?= base_url('user'); ?>#process" class="scroll">Layanan</a></li>
                    <li><a href="<?= base_url('user'); ?>#works" class="scroll">Galeri Foto</a></li>
                    <li><a href="<?= base_url('user'); ?>#vismis" class="scroll">Visi Misi</a></li>
                    <li><a href="<?= base_url('user/lakip'); ?>">Lakip</a></li>
                    <li><a href="<?= base_url('user/struktur'); ?>">Struktur Organisasi</a></li>
                   
                    
                </ul>
            </nav><!-- /.navbar-collapse -->
        </div>
    </header>
    <div class="home-banner fullscreen" >
        <div class="gradient"></div>
        <div class="banner-content dtable fullscreen">
            <div class="content-inner dtablecell">
                <div class="container">
                    <h1>Website Socah</h1>
                    <p>Portal Berita dan Informasi Masyarakat Socah</p>
                </div>
            </div>
        </div>
    </div>
<div id="process" class="process sectionbaca">
    <div class="container">
        <div class="row">
            <div class="baca">
            <h2>PROSEDUR PEMBUATAN AKTA CATATAN SIPIL</h2>
            </div>
        </div>

        <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">AKTA CATATAN SIPIL</th>
            
            </tr>
          </thead>
          <tbody>
            <tr>
               <td align="justify" colspan="2">LINDUNGI HAK HAK SIPIL ANDA DENGAN AKTA AKTA CATATAN SIPIL
                3 UU NO. 24 TAHUN 2013 TENTANG PERUBAHAN ATAS UU NOMOR 23 TAHUN 2006 TENTANG ADMINISTRASI KEPENDUDUKAN DI SEBUTKAN BAHWA PENCATATAN SIPIL ADALAH PENCATATAN PERISTIWA PENTING YANG DIALAMI OLEH SESEORANG DALAM REGISTER PENCATATAN SIPIL PADA INSTANSI PELAKSANA. 
                YANG DI SEBUT PERISTIWA PENTING ADALAH KEJADIAN YANG DIALAMI OLEH SESEORANG MELIPUTI ANTARA LAIN PERISTIWA KELAHIRAN,KEMATIAN, PERKAWINAN, PERCERAIAN, PENGESAHAN DAN PENGAKUAN ANAK.
                INSTANSI PELAKSANA YANG DIBERI KEWENANGAN MELAKSANAKAN PENDAFTARAN PERISTIWA KEPENDUDUKAN DAN MENCATAT PERISTIWA PENTING/ PENCATATAN SIPIL ADALAH DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL.</td>
            </tr>    
          </tbody>
        </table>

        <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">DASAR HUKUM PENCATATAN KELAHIRAN</th>
            
            </tr>
          </thead>
          <tbody>
            <tr>
               <td colspan="2">Setiap kelahiran wajib dilaporkan oleh penduduk (Pasal 27 UU No. 24 Tahun 2013).</td>
            </tr>
            <tr>
               <td colspan="2">Persyaratan dan tatacara (Permendagri No. 9 Tahun 2016)</td>
            </tr>
          </tbody>
        </table>

        <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">MANFAAT</th>
            
            </tr>
          </thead>
          <tbody>
            <tr>
               <td colspan="2">1.  Masuk sekolah</td>
            </tr>
            <tr>
               <td colspan="2">2.  Mengurus beasiswa</td>
            </tr>
            <tr>
               <td colspan="2"> 3.  Rujukan penerbitan ijazah</td>
            </tr>
            <tr>
               <td colspan="2">4.  Pembuatan KIA</td>
            </tr>
            <tr>
               <td colspan="2">5.  Pembuatan KTP-el</td>
            </tr>
            <tr>
               <td colspan="2">6.  Perbuatan paspor</td>
            </tr>
            <tr>
               <td colspan="2">7.  Pengurusan tunjangan keluarga</td>
            </tr>
            <tr>
               <td colspan="2">8.  Pengurusan warisan</td>
            </tr>
            <tr>
               <td colspan="2">9.  Melamar pekerjaan</td>
            </tr>
            <tr>
               <td colspan="2">10. Pencatatan perkawinan</td>
            </tr>
            <tr>
               <td colspan="2">11. Pencatatan pengangkatan, pengakuan dan pengesahan anak</td>
            </tr>
          </tbody>
        </table>

         <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">PERSYARATAN PENERBITAN AKTA AKTA CATATAN SIPIL</th>
            
            </tr>
          </thead>
          <tbody>
            <tr>
               <td colspan="2" style="font-weight: bold;">Akta kelahiran usia 0-60hari</td>
            </tr>
            <tr>
               <td colspan="2">1.  Fc. Kartu Keluarga Orang Tua</td>
            </tr>
            <tr>
               <td colspan="2">2.  Fc.KTP-El / Surat Kematian Orang Tua </td>
            </tr>
            <tr>
               <td colspan="2">3.  Surat Kelahiran Anak dari Bidan/Dokter/Rumah Sakit/ Puskesmas/Penolong Kelahiran. (Asli) </td>
            </tr>
            <tr>
               <td colspan="2">4.  Fc.Akta Nikah (Muslim) / Kutipan Akta Perkawinan (Non Muslim) /Kutipan Akta Perceraian yang Dilegalisir Instansi yang Berwenang/STPJM Bagi yang tidak memiliki Akta Nikah/Akta Perkawinan.</td>
            </tr>
            <tr>
               <td colspan="2">5.  2 orang saksi + fc KTP el Nya </td>
            </tr>
            <tr>
               <td colspan="2">6.  Formulir F2.01 yang sudah ditandatangani pelapor dan Kepala Desa/Lurah.</td>
            </tr>
            <tr>
               <td colspan="2" style="font-weight: bold;">Akta Kelahiran Usia 60 hari keatas </td>
            </tr>
            <tr>
               <td colspan="2">1.  fc.Kartu Keitiarua Orang Tua </td>
            </tr>
            <tr>
               <td colspan="2">2.  Fc.KTP-el Surat Kematian Orang Tua</td>
            </tr>
            <tr>
               <td colspan="2">3.  Surat Kelahiran Anak dari Bidan/Dokier/Rumah Sakit/Puskesmas/Penolong Kelahiran) (Asli) /SPTJM Biodata Kelahiran.</td>
            </tr>
            <tr>
               <td colspan="2">4.  Fc.Akta Nikah (Muslim) / Kutipan Akta Perkawinani (Non Muslim) /Kutipan Akta Perceraian yang Dilegalisir Instansi yang Berwenang/STPJM Bagi yang tidak memiliki Akta Nikah/Akta Perkawinan</td>
            </tr>
            <tr>
               <td colspan="2">5.  2 orang saksi +fc. KTP- el nya.</td>
            </tr>
            <tr>
               <td colspan="2">6.  Formulir F2.01 yang sudah ditandatangani pelapor dan Kepala Desa/Lurah. </td>
            </tr>
            <tr>
               <td colspan="2">7.  Surat Keputusan dari Kepala Dinas Kependudukandan Pencatatan Sipil.</td>
            </tr>
            <tr>
               <td colspan="2">8.  Fc.KTP-el yang bersanlutan jika sudah Wajib KTP-el.</td>
            </tr>
            <tr>
               <td colspan="2" style="font-weight: bold;">Akta Kematian</td>
            </tr>
            <tr>
               <td colspan="2">1.  Mengisi Form F2.28 yang ditandatangani Pelapor</td>
            </tr>
            <tr>
               <td colspan="2">2.  Mengisi Form F2.29 yang ditandatangani Kepala Desa /Lurah</td>
            </tr>
            <tr>
               <td colspan="2">3.  Surat Keterangan Meninggal dari Rumah Sakit/ Dokter.</td>
            </tr>
            <tr>
               <td colspan="2">4.  Foto Copy Kartu Keluarga </td>
            </tr>
            <tr>
               <td colspan="2">5.  Foto Copy KTP-el Yang meninggal</td>
            </tr>
            <tr>
               <td colspan="2">6.  2 orang saksi + fotocopy KTP-el</td>
            </tr>
            <tr>
               <td colspan="2">7.  Foto Copy KTP-el Pelapor </td>
            </tr>
            <tr>
               <td colspan="2" style="font-weight: bold;">Akta Pengakuan Anak</td>
            </tr>
            <tr>
               <td colspan="2">1.  Surat Pengantar dari RT/RW dan diketahui oleh Desa/ Lurah.</td>
            </tr>
            <tr>
               <td colspan="2">2.  Kutipan Akta Kelahiran Anak (Asli).</td>
            </tr>
            <tr>
               <td colspan="2">3.  FC. Kartu Keluarga Ayah Biologis</td>
            </tr>
            <tr>
               <td colspan="2">4.  FC. KTP-el Ayah Biologis</td>
            </tr>
            <tr>
               <td colspan="2">5.  FC. Kartu Keluarga lbu Kandung</td>
            </tr>
            <tr>
               <td colspan="2">6.  FC. KTP-el Ibu Kandung</td>
            </tr>
            <tr>
               <td colspan="2">7.  Surat Pengakuan Anak dari ayah Biologis yang di setujui oleh Ibu Kandung</td>
            </tr>
            <tr>
               <td colspan="2">8.  Mengisi formulir Permohonan F2.38</td>
            </tr>
            <tr>
               <td colspan="2">9.  Saksi 2 dua orang dengan FC.KTP-el</td>
            </tr>
            <tr>
               <td colspan="2" style="font-weight: bold;">Akta Pengesahan Anak</td>
            </tr>
            <tr>
               <td colspan="2">1.  Surat Pengantar dari RT/RW dan diketahui oleh Desa/ Lurah.</td>
            </tr>
            <tr>
               <td colspan="2">2.  Kutipan Akta Kelahiran yang asli</td>
            </tr>
            <tr>
               <td colspan="2">3.  FC. Kutipan Akta Perkawinan</td>
            </tr>
            <tr>
               <td colspan="2">4.  FC. Kartu Keluarga</td>
            </tr>
            <tr>
               <td colspan="2">5.  FC. KTP-el Pemohon</td>
            </tr>
            <tr>
               <td colspan="2">6.  Mengisi formulir Permohonan F2.40</td>
            </tr>
            <tr>
               <td colspan="2" style="font-weight: bold;">Akta Perkawinan</td>
            </tr>
            <tr>
               <td colspan="2">1.  FC. Surat Keterangan Perkawinan dari Pemuka Agama atau penghayat kepercayaan / Salinan pengadilan</td>
            </tr>
            <tr>
               <td colspan="2">2.  FC.Kutisan Akta Kelahiran</td>
            </tr>
            <tr>
               <td colspan="2">3.  Surat Keterangan dari Desa / Kelurahan (N1,N2,dst).</td>
            </tr>
            <tr>
               <td colspan="2">4.   Fc.Kartu Keluarga dan Fc. KTP el </td>
            </tr>
            <tr>
               <td colspan="2">5.  Pas Poto Berdampingan ukuran 4x6 sebanyak 3 lembar (berwarna) </td>
            </tr>
            <tr>
               <td colspan="2">6.  1 (satu ) orang saksi dan fc. KTP el nya (yang sudah berusia 21 th ke atas)</td>
            </tr>
            <tr>
               <td colspan="2">7.  Kutipan Akta Kelahiran Anak yang akan diakui/disahkan</td>
            </tr>
            <tr>
               <td colspan="2">8.  Fc.Akta Perceraian/ Kematian jika yang bersangkutan telah pernah kawin / meninggal dunia.</td>
            </tr>
            <tr>
               <td colspan="2">9.  Ijin dari Komandan bagi anggota TNI/POLRI</td>
            </tr>
            <tr>
               <td colspan="2">10. Perjanjian Perkawinan.</td>
            </tr>
            <tr>
               <td colspan="2">11. STMD dad Kepolisian</td>
            </tr>
            <tr>
               <td colspan="2">12. Surat Ijin dari istri bagi yang bepoligami</td>
            </tr>
            <tr>
               <td colspan="2">13. Surat ijin dari Pengadilan Negeri bagi yang berpoligami</td>
            </tr>
            <tr>
               <td colspan="2">14. Surat ijin dari Perwakilan Negara Asing yang bersangkutan.</td>
            </tr>
            <tr>
               <td colspan="2">15. Fc.Paspor/Dokurnen Keimigrasian </td>
            </tr>
            <tr>
               <td colspan="2">16. Fc. KTP Orang TuaNVali/ Surat Kematian Orang Tua.</td>
            </tr>
            <tr>
               <td colspan="2">17. Mengisi formulir F-2.12</td>
            </tr>
            <tr>
               <td colspan="2">18. Surat Keterangan Belum Tercatat Perkawinan dari Dispenduk Asal (untuk Luar Kota )</td>
            </tr>
            <tr>
               <td colspan="2" style="font-weight: bold;">Pencatatan Akta Perceraian</td>
            </tr>
            <tr>
               <td colspan="2">1.  Salinan Penetapan Pengadilan Negeri yang sudah mempunyai kekuatan hukum tetap.</td>
            </tr>
            <tr>
               <td colspan="2">2.  Pas Foto ukuran 4 x 6 sebanyak 3 (tiga) lembar</td>
            </tr>
            <tr>
               <td colspan="2">3.  Surat kuasa dan KTP-el bagi yang dikuasakan</td>
            </tr>
            <tr>
               <td colspan="2">4.  Kutipan Akta Perkawinan Asli</td>
            </tr>
            <tr>
               <td colspan="2">5.  Fc. KTP-el dan Fc. Kartu Keluarga</td>
            </tr>
            <tr>
               <td colspan="2">6.  Mengisi Formulir F-2.19</td>
            </tr>

          </tbody>
        </table>


        <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">Catatan</th>
            
            </tr>
          </thead>
          <tbody>
            <tr>
               <td colspan="2">•   Pencatatan sipil dilakukan berdasarkan azas domisili</td>
            </tr>
            <tr>
               <td colspan="2">•   Fotocopy berkas dilegalisir pihak yang berwenang</td>
            </tr>

          </tbody>
        </table>

    </div>
</div>
    
    <footer class="footer">
        <div class="container text-center wow zoomIn">
            <div class="social-icons clearfix">
                <a class="facebook" href="https://m.facebook.com/kecamatan.socah?ref=bookmarks">
                    <i class="fab fa-facebook"></i> 
                </a>
                
                <!--instagram-->
                <a class="linkedin" href="https://www.instagram.com/kecamatansocah/">
                    <i class="fab fa-instagram"></i> 
                </a>

                <a class="twitter" href="https://twitter.com/KecamatanSocah?s=08">
                    <i class="fab fa-twitter-square"></i> 
                </a>
             
                
                <!--
                <a class="googleplus" href="">
                    <i class="icon-googleplus"></i>
                </a>
                -->   
                
            </div> 

            <div class="copyright">
                <p>Copyright&copy;<a href="">Kecamatan Socah</a>,<?= date('Y'); ?></p>
            </div>
        </div>
    </footer>


        <!--
        JavaScripts
        ========================== -->
        


      <script src=" <?= base_url('assets/'); ?>js/vendor/jquery-1.11.1.min.js"></script>
      <script src=" <?= base_url('assets/'); ?>js/bootstrap.min.js"></script>
      <script src=" <?= base_url('assets/'); ?>js/owl.carousel.js"></script>
      <script src=" <?= base_url('assets/'); ?>js/wow.min.js"></script>
      <script src=" <?= base_url('assets/'); ?>js/jquery.justifiedGallery.min.js"></script>
      <script src=" <?= base_url('assets/'); ?>js/script.js"></script>
      <script src=" <?= base_url('assets/'); ?>js/main.js"></script>
        
    </body>
</html>