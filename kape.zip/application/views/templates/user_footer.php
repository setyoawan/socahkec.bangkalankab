<footer class="footer">
            <div class="container text-center wow zoomIn">
                <div class="social-icons clearfix">
                    <a class="facebook" href="https://m.facebook.com/kecamatan.socah?ref=bookmarks">
                        <i class="fab fa-facebook"></i> 
                    </a>
                    
                    <!--instagram-->
                    <a class="linkedin" href="https://www.instagram.com/kecamatansocah/">
                        <i class="fab fa-instagram"></i> 
                    </a>

                    <a class="twitter" href="https://twitter.com/KecamatanSocah?s=08">
                        <i class="fab fa-twitter-square"></i> 
                    </a>
                 
                    
                    <!--
                    <a class="googleplus" href="">
                        <i class="icon-googleplus"></i>
                    </a>
                    -->   
                    
                </div> 

                <div class="copyright">
                    <p>Copyright&copy;<a href="">Kecamatan Socah</a>,<?= date('Y'); ?></p>
                </div>
            </div>
        </footer>


        <!--
        JavaScripts
        ========================== -->
        


        <script src=" <?= base_url('assets/'); ?>js/vendor/jquery-1.11.1.min.js"></script>
        <script src=" <?= base_url('assets/'); ?>js/bootstrap.min.js"></script>
        <script src=" <?= base_url('assets/'); ?>js/owl.carousel.js"></script>
        <script src=" <?= base_url('assets/'); ?>js/wow.min.js"></script>
        <script src=" <?= base_url('assets/'); ?>js/jquery.justifiedGallery.min.js"></script>
        <script src=" <?= base_url('assets/'); ?>js/script.js"></script>
        <script src=" <?= base_url('assets/'); ?>js/main.js"></script>
        
    </body>
</html>
